import { UpdateCardProps } from '../../types';
import { data as proceduralCity } from './procedural-city';

export const experiments: UpdateCardProps[] = [
  proceduralCity,
  // Add new experiment imports above and register them in this array
];